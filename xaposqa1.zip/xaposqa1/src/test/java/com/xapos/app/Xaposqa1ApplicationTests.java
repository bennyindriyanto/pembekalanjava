package com.xapos.app;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Xaposqa1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
