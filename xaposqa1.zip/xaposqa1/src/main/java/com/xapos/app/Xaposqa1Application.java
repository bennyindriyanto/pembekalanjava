package com.xapos.app;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Xaposqa1Application {

	public static void main(String[] args) {
		SpringApplication.run(Xaposqa1Application.class, args);
	}

}
