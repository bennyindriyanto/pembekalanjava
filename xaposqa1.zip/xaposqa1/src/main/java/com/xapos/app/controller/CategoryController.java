package com.xapos.app.controller;

import java.util.List;
import java.util.Date;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.xapos.app.model.Category;
import com.xapos.app.repository.CategoryRepository;

@Controller
@RequestMapping("/category/")

public class CategoryController {
		@Autowired
		private CategoryRepository categoryRepository;
		
		@GetMapping("index")
		public ModelAndView index() {
			ModelAndView view = new ModelAndView("category/index.html");
//			List<Category> listCategory = this.categoryRepository.findAll(Sort.by(Sort.Direction.ASC,"id"));
			List<Category> listCategory = this.categoryRepository.findByIsActive(true,Sort.by(Sort.Direction.ASC,"id"));
			view.addObject("listCategory", listCategory);
			return view;
		}
		@GetMapping("addform")
		public ModelAndView addform() {
			ModelAndView view = new ModelAndView("category/addform.html");
			Category category = new Category();
			view.addObject("category",category);
			return view;
		}
		
		@PostMapping("save")
		public ModelAndView save(@ModelAttribute Category category, BindingResult Result) {
			if(!Result.hasErrors()) {
				if(category.getId() == null) {
					category.setCreateBy("admin1");
					category.setCreateDate(new Date());
				}else {
					Category tempCat = this.categoryRepository.findById(category.getId()).orElse(null);
					if(tempCat != null) {
						category.setCreateBy(tempCat.getCreateBy());
						category.setCreateDate(tempCat.getCreateDate());
						category.setModifyBy("admin2");
						category.setModifyDate(new Date());
					}
				}
				this.categoryRepository.save(category);
				return new ModelAndView("redirect:/category/index");
				
			}else {
				return new ModelAndView("redirect:/category/index");
			}
			
		}
		
		@GetMapping("editform/{id}")
		public ModelAndView editForm(@PathVariable("id")Long id) {
			ModelAndView view = new ModelAndView("category/addform.html");
			Category category = this.categoryRepository.findById(id).orElse(null);
			System.out.println(category);
			view.addObject("category",category);
			return view;
		}
		
		@GetMapping("delete/{id}")
		public ModelAndView delete(@PathVariable("id")Long id) {
			if(id != null) {
				Category category = this.categoryRepository.findById(id).orElse(null);
				category.setIsActive(false);
				category.setModifyBy("admin3");
				category.setModifyDate(new Date());
				this.categoryRepository.save(category);
			}

			return new ModelAndView("redirect:/category/index");
		}
}
