package com.xapos.app.controller;

import java.util.Date;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Controller;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import com.xapos.app.model.Category;
import com.xapos.app.model.Variant;
import com.xapos.app.repository.CategoryRepository;
import com.xapos.app.repository.VariantRepository;

@Controller
@RequestMapping("/variant/")
public class VariantController {
	
		@Autowired
		private VariantRepository variantRepository;
		
		@Autowired
		private CategoryRepository categoryRepository;
		
		@GetMapping("index")
		public ModelAndView index() {
			ModelAndView view = new ModelAndView("variant/index.html");
			List<Variant> listVariant = this.variantRepository.findByIsActive(true, Sort.by(Sort.Direction.ASC,"id"));
			view.addObject("listVariant", listVariant);
			return view;
	}
		@GetMapping("admin")
		public ModelAndView admin() {
			ModelAndView view = new ModelAndView("variant/admin.html");
			List<Variant> listVariant = this.variantRepository.findAll();
			view.addObject("listVariant", listVariant);
			return view;
	}
		
		@GetMapping("addform")
		public ModelAndView addform() {
			ModelAndView view = new ModelAndView("variant/addform.html");
			List<Category> listCategory = this.categoryRepository.findByIsActive(true, Sort.by(Sort.Direction.ASC,"id"));
			view.addObject("listCategory", listCategory);
			
			Variant variant = new Variant();
			view.addObject("variant",variant);
			return view;
	}
		
		@PostMapping("save")
		public ModelAndView saveVarian(@ModelAttribute Variant variant,BindingResult result) {
			if(!result.hasErrors()) {
				if(variant.getId() == null) {
					variant.setCreateBy("admin1");
					variant.setCreateDate(new Date());
				}else {
					Category tempCat = this.categoryRepository.findById(variant.getId()).orElse(null);
					if(tempCat != null) {
						variant.setCreateBy(tempCat.getCreateBy());
						variant.setCreateDate(tempCat.getCreateDate());
						variant.setModifyBy("admin2");
						variant.setModifyDate(new Date());
					}
				}
				this.variantRepository.save(variant);
				return new ModelAndView("redirect:/variant/index");
			}else {
			return new ModelAndView("redirect:/variant/index");
		}
			}
		
		@GetMapping("editform/{id}")
		public ModelAndView editForm(@PathVariable("id")Long id) {
			ModelAndView view = new ModelAndView("variant/addform.html");
			Variant variant = this.variantRepository.findById(id).orElse(null);
			System.out.println(variant);
			view.addObject("variant",variant);
			return view;
		}
		
		@GetMapping("delete/{id}")
		public ModelAndView delete(@PathVariable("id")Long id) {
			if(id != null) {
				Variant variant = this.variantRepository.findById(id).orElse(null);
				variant.setIsActive(false);
				variant.setModifyBy("admin3");
				variant.setModifyDate(new Date());
				this.variantRepository.save(variant);
			}

			return new ModelAndView("redirect:/variant/index");
		}
		
}		
		
