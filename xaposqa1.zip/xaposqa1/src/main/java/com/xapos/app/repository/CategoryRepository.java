package com.xapos.app.repository;

import org.springframework.data.domain.Sort;
import org.springframework.data.jpa.repository.JpaRepository;
import com.xapos.app.model.Category;
import java.util.List;

public interface CategoryRepository extends JpaRepository<Category, Long>{
	List<Category> findByIsActive(Boolean isActive, Sort sort);
}
